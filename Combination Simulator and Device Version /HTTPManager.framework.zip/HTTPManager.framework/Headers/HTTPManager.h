//
//  HTTPManager.h
//  HTTPManager
//
//  Created by Francis Chan on 6/3/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HTTPManager.
FOUNDATION_EXPORT double HTTPManagerVersionNumber;

//! Project version string for HTTPManager.
FOUNDATION_EXPORT const unsigned char HTTPManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HTTPManager/PublicHeader.h>
